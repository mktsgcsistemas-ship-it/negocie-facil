import React from 'react';
import Header from './Header';
import Footer from './Footer';

export default function MainLayout({children}){
  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: '#737F8B' }}>
      <Header />
      <main className="flex-1 flex items-center justify-center p-4">
        {children}
      </main>
      <Footer />
    </div>
  )
}