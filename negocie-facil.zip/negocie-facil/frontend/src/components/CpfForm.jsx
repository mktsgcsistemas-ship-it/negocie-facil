import React, {useState} from 'react';
import { mascararCpf, validarCpf } from '../utils/cpf';

export default function CpfForm({ onPropostas }){
  const [cpf, setCpf] = useState('');
  const [error, setError] = useState('');

  const consultar = async () => {
    const limpo = cpf.replace(/\D/g,'');
    if (!validarCpf(limpo)){
      setError('CPF inválido');
      return;
    }
    setError('');
    try{
      const res = await fetch(`/consultar/${limpo}`);
      const data = await res.json();
      // backend returns dividas -> proposals in mock: create proposals array
      const proposals = data.dividas && data.dividas[0] && data.dividas[0].propostas
        ? data.dividas[0].propostas.map(p => ({ valor: (typeof p.valor === 'number' ? p.valor.toFixed(2) : p.valor), parcelas: p.tipo==='3x'?3:1, desconto: Math.round((1 - (typeof p.valor==='number' and p.valor>0 and p.valor) )?0:0) }))
        : [];
      // simpler mapping: backend mock has numeric values: we'll map directly
      const mapped = (data.dividas && data.dividas[0] && data.dividas[0].propostas) ? data.dividas[0].propostas.map(p=>({valor: p.valor, parcelas: p.tipo==='3x'?3:1, desconto: p.tipo==='À vista'?20:10})) : [];
      onPropostas(mapped);
    }catch(err){ setError('Erro ao consultar') }
  };

  return (
    <div className="bg-white shadow-xl rounded-2xl p-6 flex flex-col gap-4">
      <img src="/logo.png" alt="Logo" className="h-12 mx-auto" />
      <h1 className="text-xl font-semibold text-[#707070] text-center">Negocie Fácil</h1>
      <input type="text" placeholder="Digite seu CPF" className="border rounded p-3 text-[#707070]" value={cpf} onChange={e=>setCpf(mascararCpf(e.target.value))} />
      {error && <p className="text-red-600 text-sm">{error}</p>}
      <button className="bg-[#264967] text-[#FFD306] p-3 rounded-xl font-bold hover:opacity-90" onClick={consultar}>Consultar Dívida</button>
    </div>
  )
}