module.exports = {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter", "sans-serif"],
      },
      colors: {
        primary: '#264967',
        accent: '#FFD306',
        bg: '#737F8B',
        textmuted: '#707070'
      }
    },
  },
  plugins: [],
};