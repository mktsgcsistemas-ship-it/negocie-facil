import React from 'react';
export default function Header(){ return (
  <header className="w-full p-4 flex items-center justify-center bg-transparent">
    <img src="/logo.png" alt="Logo" className="h-14 drop-shadow-md" />
  </header>
)}