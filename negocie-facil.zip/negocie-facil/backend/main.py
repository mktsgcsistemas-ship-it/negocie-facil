from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/consultar/{cpf}")
def consultar_dividas(cpf: str):
    return {
        "cpf": cpf,
        "status": "ok",
        "dividas": [
            {
                "id": 1,
                "empresa": "Financeira XPTO",
                "valor": 1520.75,
                "propostas": [
                    {"tipo": "À vista", "valor": 980.00},
                    {"tipo": "3x", "valor": 350.00},
                    {"tipo": "6x", "valor": 200.00}
                ],
            }
        ],
    }
