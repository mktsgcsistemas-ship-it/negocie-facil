import React, {useState} from 'react';
import MainLayout from '../components/MainLayout';
import CpfForm from '../components/CpfForm';
import RightPanel from '../components/RightPanel';
import Modal from '../components/Modal';

export default function Home(){
  const [modalOpen, setModalOpen] = useState(false);
  const [propostas, setPropostas] = useState([]);

  const handlePropostas = (lista) => {
    setPropostas(lista);
    setModalOpen(true);
  };

  return (
    <MainLayout>
      <div className="flex w-full max-w-5xl rounded-2xl overflow-hidden shadow-2xl bg-white">
        <div className="w-full md:w-1/2 p-8 flex flex-col justify-center">
          <h1 className="text-3xl font-bold text-gray-700 mb-6">Consultar Dívidas</h1>
          <p className="text-gray-600 mb-6">Digite seu CPF para continuar.</p>
          <CpfForm onPropostas={handlePropostas} />
        </div>
        <RightPanel />
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)}>
        <h2 className="text-xl font-bold text-gray-700 mb-4">Propostas</h2>
        <div className="flex flex-col gap-3 max-h-80 overflow-auto">
          {propostas.length === 0 && <p className="text-gray-600">Nenhuma proposta.</p>}
          {propostas.map((p, i) => (
            <div key={i} className="p-3 border rounded-md">
              <div><strong>Valor:</strong> {p.valor}</div>
              <div><strong>Parcelas:</strong> {p.parcelas}</div>
              <div><strong>Desconto:</strong> {p.desconto}%</div>
            </div>
          ))}
        </div>
      </Modal>
    </MainLayout>
  )
}