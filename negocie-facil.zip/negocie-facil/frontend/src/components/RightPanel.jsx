import React from 'react';
export default function RightPanel(){ return (
  <div className="hidden md:flex flex-col items-center justify-center w-1/2 bg-cover bg-center p-10" style={{ backgroundImage: "url('/fundo.png')" }}>
    <div className="bg-white bg-opacity-80 p-8 rounded-2xl shadow-xl max-w-sm text-center">
      <h2 className="text-2xl font-bold text-gray-700 mb-4">Bem-vindo ao Negocie Fácil</h2>
      <p className="text-gray-600 text-sm">Consulte e negocie suas dívidas de forma rápida, segura e totalmente online.</p>
    </div>
  </div>
)}