import React from 'react';
export default function Footer(){ return (
  <footer className="w-full text-center p-4 text-sm text-gray-300 mt-10">
    © 2025 Negocie Fácil — Autoatendimento seguro e rápido.
  </footer>
)}